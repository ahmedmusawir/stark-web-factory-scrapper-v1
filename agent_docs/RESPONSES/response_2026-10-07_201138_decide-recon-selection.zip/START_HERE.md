# START HERE — Web Factory DECIDE review

**Requested decision:** JARVIS reviews the implementation, source diff and illustrative selection/export; Tony decides whether to authorize the proposed bounded four-call live recon. No live recon was performed in this task.

1. Open `agent_docs/RESPONSES/response_2026-10-07_201138_decide-recon-selection.md`.
2. Read `agent_docs/ACTION/wf-scrapper-abm/DECIDE.md` for exact commands and limits.
3. Review `agent_docs/ACTION/wf-scrapper-abm/EVIDENCE/decide/2026-10-07_135659Z/source-test.diff.txt`, `recon_pipeline/decide.py` and `tests/test_decide.py`.
4. Open `agent_docs/ACTION/wf-scrapper-abm/EVIDENCE/decide/2026-10-07_135659Z/sample-final/review/INVENTORY.md`, then EXAMPLE_ONLY_decision.json and EXAMPLE_ONLY_collector-plan.json in sample-final.
5. Review the 84-pass local check log and native loopback evidence under verified-final.

Branch wf-scrapper-abm; full HEAD 2824afb773d02bb4e0e7387710f1e7917858be8e plus dirty/untracked source. Final 50-file source inventory SHA-256 ebc6e8310ce4aab49a93ec6cc3c2011fbddeb404642362a6fc442a71ae77b864. All 48 previous code/test files, including the working collector, are unchanged. Independent QA NOT RUN. Prepare not built.

The sample is IMPORTED_CAPTURE_INVENTORY, not fresh recon. Choices are illustrative, not Tony approval. One document selected for REST becomes one item endpoint, not permission for all posts. Historical empty content is preserved and flagged for HTML review.

The ZIP includes the new source/test diff, implementation/tests, relevant unchanged source helpers, current instructions/checkpoints, sample JSON/listing/decision/plan, source inventory, local test evidence and preservation proof. It is a review package, not an installed runnable distribution. FILE_HASHES.json covers the included files.

Excluded: raw website captures, bulk historical evidence, runtime caches, dependencies and environment/credential files. References to preserved raw evidence (including absolute local source locators in imported inventories) require the repository. No previous output/evidence file was changed. No archive item requests live execution automatically.
