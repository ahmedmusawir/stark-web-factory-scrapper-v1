# START HERE — recon types and labels repair

**Done:** both scoped fixes implemented and engineering-verified. 35 focused checks passed. One REST-only live run made three planned calls, all HTTP200; no cleanup error reported.

**Counts:** types endpoint described33 types. Pages advertised42 records, but only1 metadata record was sampled. Posts advertised166, but only1 was sampled. Full content/custom/media collections were not requested.

**Preservation:** all42,686 previous output/evidence/report files unchanged; original36-row inventory/old[] remain unchanged. All candidate choices remain UNDECIDED. Collector source is unchanged.

Read:

1. [response_2026-10-10_195853_recon-types-label-fixes.md](response_2026-10-10_195853_recon-types-label-fixes.md) — human report, exact URLs, outcomes, limits and next move.
2. [source-test-doc.diff.txt](source-test-doc.diff.txt) — exact two-file code/test changes plus the local operating instruction update.
3. [evidence/checks-final.json](evidence/checks-final.json) — focused results, hashes, label and preservation proofs.
4. [evidence/rest-live/result.json](evidence/rest-live/result.json) — live timings, headers, counts, body sizes and cleanup.
5. [evidence/saved-label-proof.json](evidence/saved-label-proof.json) — nine informative headings survive generic links with same IDs/provenance.

Source snapshots are under source/. Small byte-faithful REST JSON responses are under evidence/rest-live/evidence/. The original two-byte [] is under historical/ with its original reference/hash; it was not refetched. Checkpoint diff preserves prior dirty records; this is not a combined Git diff against HEAD.

Base HEAD fb16b1b927a234d74a2c29c9044df33317ff8276; branch wf-scrapper-abm.
Final/test/live50-file inventory:32cbd7e9f47137afb754b4954bc402ddae7319f2153895f8c16e092e82b91f2f.
HASHES.json inventories all other ZIP members. Raw saved blog/capture dumps, dependencies, runtime caches and bulk historical evidence are excluded. No credentials, cookies or private headers are packaged.

**Next move:** JARVIS reviews implementation/results; Tony reviews numbered candidates. No decisions, capture, further live request or Prepare work were performed. Independent QA NOT RUN. STOP.
