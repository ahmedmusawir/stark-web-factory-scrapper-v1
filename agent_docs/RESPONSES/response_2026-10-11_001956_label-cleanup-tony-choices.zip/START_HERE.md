# START HERE — Tony’s corrected choices

**Done:** all9 article labels exactly match the saved blog headings;55 focused DECIDE checks passed. No live request or collection ran.

The earlier October10 preservation claim was incorrect: its proof stored ellipses and checked only for non-CTA text. That historical proof/ZIP/REST evidence remains unchanged; the earlier report has an append-only correction.

Read:

1. [response_2026-10-11_001956_label-cleanup-tony-choices.md](response_2026-10-11_001956_label-cleanup-tony-choices.md) — concise report/correction, source and check results.
2. [response_2026-10-11_001956_label-cleanup-tony-choices_review/TONY_CHOICES.md](response_2026-10-11_001956_label-cleanup-tony-choices_review/TONY_CHOICES.md) — all36 numbered choices, URLs, provenance and gaps.
3. [response_2026-10-11_001956_label-cleanup-tony-choices_review/inventory.json](response_2026-10-11_001956_label-cleanup-tony-choices_review/inventory.json) — new immutable version; all UNDECIDED.
4. [response_2026-10-11_001956_label-cleanup-tony-choices_review/corrected-nine-labels.json](response_2026-10-11_001956_label-cleanup-tony-choices_review/corrected-nine-labels.json) — independent saved-heading/actual-label exact comparisons.
5. [response_2026-10-11_001956_label-cleanup-tony-choices_diff.txt](response_2026-10-11_001956_label-cleanup-tony-choices_diff.txt) — focused source/test/instruction diff. evidence/scoped.diff.txt also contains checkpoint and earlier-report corrections.
6. [response_2026-10-11_001956_label-cleanup-tony-choices_checks.json](response_2026-10-11_001956_label-cleanup-tony-choices_checks.json) — complete focused/source/preservation checks.

Recommendation only: first HTML batch rows1Home,3AgencyServices,9Andromeda. Tony chooses HTML/REST separately. No automatic plan export. Post11945’s empty-content warning stays visible.

REST snapshot is imported October10 evidence:33 type descriptions; pages42advertised but1sampled metadata record; posts166advertised but1sampled metadata record. No REST request was repeated. Other collections remain unknown.

Base HEAD fb16b1b927a234d74a2c29c9044df33317ff8276; branch wf-scrapper-abm.
Final/tested50-file inventory:609d3493a7f45bcb151c74c22275c35de171fc015886e40fb4547b6a020eb729.
HASHES.json covers every other packaged file. Preserved raw HTML is excluded from the ZIP; in the repository the canonical review has its byte-faithful copy at agent_docs/RESPONSES/response_2026-10-11_001956_label-cleanup-tony-choices_review/evidence/0001.body, matching outputs/recon/CyberizeGroup-default-01/evidence/0001.body. Both SHA-256:0867a82223dfb0f3c6781062ebbf6894586200468521074c740e02bbdc3271ab. Source locators/hashes remain in the inventory/proof. Browser caches, dependencies and bulk historical captures are excluded.

Independent QA NOT RUN. No Git mutations, dependencies or Prepare work. STOP for Tony’s choices.
