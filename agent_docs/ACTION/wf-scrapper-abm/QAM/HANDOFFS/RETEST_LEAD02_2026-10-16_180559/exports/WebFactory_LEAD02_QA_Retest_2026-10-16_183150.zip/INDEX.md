# WebFactory_LEAD02_QA_Retest_2026-10-16_183150

LEAD-02 independent QA retest package. Not a certificate: JARVIS adjudicates, Tony decides.

- `RETEST_LEAD02_2026-10-16_180559/EXECUTION_REPORT.md` — start here (ZIP hash receipt is in the sibling RESPONSES report, outside this ZIP)
- `RETEST_LEAD02_2026-10-16_180559/matrix/AC_EVIDENCE_MATRIX_RETEST.md` — 48-row supplemental matrix
- `RETEST_LEAD02_2026-10-16_180559/g0-identity/` — DIRECTOR GO (verbatim), identity/diff/source52/fixture verification, snapshot scoping
- `RETEST_LEAD02_2026-10-16_180559/r1/ r2/ c1/ c2/ c3/ regression/` — per-item instruments, results, runs, JUnit
- `RETEST_LEAD02_2026-10-16_180559/companions/` — LEAD-02 decision, Architect handoff, historical package-check receipts
- `records/` — RECOVERY, CHANGELOG, session log, engineering-era RESPONSES records
- `INCLUSION_EXCLUSION.json` / `MANIFEST.sha256.json` — membership and hashes
